const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// Simpele database in geheugen
let notes = {}; // { barcode: "opmerking" }

// Opmerking ophalen
app.get('/api/notes/:barcode', (req, res) => {
  const barcode = req.params.barcode;
  if (notes[barcode]) {
    res.json({ exists: true, barcode, note: notes[barcode] });
  } else {
    res.json({ exists: false, barcode });
  }
});

// Alle barcodes ophalen
app.get('/api/notes', (req, res) => {
  const list = Object.entries(notes).map(([barcode, note]) => ({ barcode, note }));
  res.json(list);
});

// Opmerking toevoegen of wijzigen
app.post('/api/notes', (req, res) => {
  const { barcode, note } = req.body;
  const existed = !!notes[barcode];
  notes[barcode] = note;
  res.json({ success: true, existed });
});

// Opmerking verwijderen
app.delete('/api/notes/:barcode', (req, res) => {
  const barcode = req.params.barcode;
  const existed = !!notes[barcode];
  delete notes[barcode];
  res.json({ success: true, existed });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API draait op poort ${PORT}`));
